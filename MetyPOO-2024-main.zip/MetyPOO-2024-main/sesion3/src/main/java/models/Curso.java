package models;

public class Curso {
    private String nombre;

    public String getNombre(){
        return this.nombre;
    }

    public Curso(){
    }

    public Curso(String nombre){
        this.nombre = nombre;
    }
}
